package org.devgroup.component;

public interface IComponent {

    void onTimeStampReceived(long[] timeStampContainer);

}
