package org.devgroup.component;

import javax.annotation.PostConstruct;

import org.devgroup.infrastructre.repository.task.CRUDTaskExecutor;
import org.devgroup.infrastructre.repository.task.RoundTripLatency;
import org.devgroup.services.lms.LMSPublisher;
import org.devgroup.services.lms.LMSSubcriber;
import org.devgroup.services.lms.message.RoundTripMessageDecoder;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.annotation.Bean;
import org.springframework.stereotype.Component;

@Component
public class LMSEngine extends CRUDTaskExecutor implements IComponent {
    
    private static Logger logger = LoggerFactory.getLogger(LMSEngine.class);
    
    private LMSSubcriber subcriber = null;
    private LMSPublisher publisher = null;
    private CRUDTaskExecutor taskExecutor = null;
    
    public LMSEngine() {
        RoundTripMessageDecoder.bootstrap();
        this.taskExecutor = new CRUDTaskExecutor();
        this.subcriber = new LMSSubcriber(this);
        try {
            this.publisher = new LMSPublisher();
        } catch (Exception e) {
            e.printStackTrace();
        }
        logger.info("LMSEngine loaded");
    }
    
    @PostConstruct
    private void run(){
        logger.info("LMSEngine Running");
    }

    @Override
    public void onTimeStampReceived(long[] timeStampContainer) {
        Long timeStampCreated = Long.valueOf(timeStampContainer[0]);
        Long timeStampSourceSent = Long.valueOf(timeStampContainer[1]);
        Long timeStampReceiverCaptured = Long.valueOf(timeStampContainer[2]);
        Long timeStampReceiverSent = Long.valueOf(timeStampContainer[3]);
        Long timeStampSourceCaputured = Long.valueOf(timeStampContainer[4]);
        RoundTripLatency recordData = new RoundTripLatency(timeStampCreated, timeStampSourceSent, timeStampReceiverCaptured, timeStampReceiverSent, timeStampSourceCaputured);
        taskExecutor.onPersistenceRequestSubmittion(new TimeSeriesPersistenceRequest(recordData));
    }

    class TimeSeriesPersistenceRequest extends PersistTask{

        public TimeSeriesPersistenceRequest(RoundTripLatency data) {
            super(data);
        }
        
    }
    
    
}
