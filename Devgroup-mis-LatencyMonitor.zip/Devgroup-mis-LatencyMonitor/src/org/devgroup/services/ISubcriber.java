package org.devgroup.services;

public interface ISubcriber {
    
    void registerInterest();
    void listen(long[] timestampContainer);
    
}
