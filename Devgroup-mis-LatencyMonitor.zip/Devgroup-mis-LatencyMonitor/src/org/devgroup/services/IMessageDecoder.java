package org.devgroup.services;

public interface IMessageDecoder {
    long[] decode(byte[] payload, long sTimestampReceived);
}
