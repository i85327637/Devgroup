package org.devgroup.services.lms;

import org.devgroup.component.IComponent;
import org.devgroup.component.LMSEngine;
import org.devgroup.infrastructre.transport.ITransport;
import org.devgroup.infrastructre.transport.TransportContext;
import org.devgroup.infrastructre.transport.socket.io.udp.unicast.SocketIOTransport;
import org.devgroup.services.IMessageConsumer;
import org.devgroup.services.ISubcriber;
import org.devgroup.services.lms.message.RoundTripLatencyMessageConsumer;
import org.devgroup.services.lms.message.RoundTripMessageDecoder;

public class LMSSubcriber implements ISubcriber {
    
//    TransportContext transportContext;
    private IComponent component = null;
    private SocketIOTransport transport = null;
    private RoundTripLatencyMessageConsumer consumer = null;
    private RoundTripMessageDecoder decoder = null;
    
    
    public LMSSubcriber(IComponent componentContext) {
        this.component = componentContext;
        this.transport = new SocketIOTransport();
        this.consumer = new RoundTripLatencyMessageConsumer(this);
        this.decoder = new RoundTripMessageDecoder();
        registerInterest();
    }
    
    @Override
    public void registerInterest() {
        this.transport.newReceiver(this.consumer);
    }

    @Override
    public void listen(long[] timeStampContainer) {
        component.onTimeStampReceived(timeStampContainer);
    }
    
}
