package org.devgroup.services.lms;

import java.net.UnknownHostException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.ScheduledThreadPoolExecutor;
import java.util.concurrent.TimeUnit;

import org.devgroup.infrastructre.transport.socket.io.udp.unicast.SocketIOTransport;
import org.devgroup.infrastructre.transport.socket.io.udp.unicast.UDPDatagramUnicastSender;
import org.devgroup.services.IMessageCreator;
import org.devgroup.services.lms.message.RoundTripMessageCreator;

public class LMSPublisher {
    
    private SocketIOTransport transport;
    private RoundTripMessageCreator creator;
    private ScheduledExecutorService executor;
    private int initialDelay = 3;
    private int interval = 5;
    private UDPDatagramUnicastSender sender;
    
    public LMSPublisher() throws Exception {
        this.transport = new SocketIOTransport();
        this.creator = new RoundTripMessageCreator();
        this.sender = notifyAdvertisement();
        this.executor = Executors.newSingleThreadScheduledExecutor();
        executor.scheduleWithFixedDelay(new Runnable() {
            
            @Override
            public void run() {
                talk();
            }
        }, initialDelay, interval, TimeUnit.SECONDS);
    }
    
    public UDPDatagramUnicastSender notifyAdvertisement() throws Exception{
        return transport.newSource();
    }
    
    public void talk(){
        byte[] outgoing = this.creator.writeMessage();
        this.sender.doSend(outgoing, outgoing.length);
    }
}
