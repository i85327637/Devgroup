package org.devgroup.services.lms.message.builder;

import org.devgroup.services.core.message.builder.IEntity;
import org.devgroup.services.core.message.builder.IPayloadBuilder;
import org.devgroup.services.lms.message.model.RoundTripLatencyMessageDTO;
import org.devgroup.services.lms.message.model.RoundTripLatencyMessageDTO.RoundTripLatencyMessage;

public class RoundTripLatencyMessageBuilder implements IPayloadBuilder {
    
    private RoundTripLatencyMessage.Builder typeBuilder;
    
//    public RoundTripLatencyMessageBuilder(Roundtriplatency record) {
//        this.typeBuilder = RoundTripLatencyMessage.newBuilder();
//        constructPayload(record);
//    }

    @Override
    public void constructPayload(IEntity entity) {
        
    }
    
    
    
}
