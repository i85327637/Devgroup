package org.devgroup.services.lms.message;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;

import org.devgroup.services.IMessageCreator;
import org.devgroup.services.lms.message.model.RoundTripLatencyMessageDTO.RoundTripLatencyMessage;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.google.protobuf.CodedOutputStream;

public class RoundTripMessageCreator implements IMessageCreator{
    
    private static Logger logger = LoggerFactory.getLogger(RoundTripMessageCreator.class);
    
    private ByteArrayOutputStream baos = null;
    private CodedOutputStream cos = null;
    int headerSize = 0;
    int messageID = 901;
    long parameterTime = 0L;
    long timestampCreated = 0L;
    private RoundTripMessageEncoder encoder;
    
    public RoundTripMessageCreator() {
        this.encoder = new RoundTripMessageEncoder();
    }
    
    public byte[] writeMessage(){
        this.baos = new ByteArrayOutputStream();
        this.timestampCreated = System.nanoTime();
        this.headerSize = CodedOutputStream.computeRawVarint32Size(messageID) + CodedOutputStream.computeRawVarint64Size(timestampCreated);
        this.cos = CodedOutputStream.newInstance(baos, headerSize);
        writeHeader();
        writePayload();
        return parseOutgoing();
    }
    
    private void writeHeader() {
        try {
            cos.writeRawVarint32(messageID);
            cos.writeRawVarint64(timestampCreated);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    
    // Dont wanna deal with encoding parameters...
    private void writePayload() {
        try {
            encoder.encode(cos, timestampCreated);
            cos.flush();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    
    private byte[] parseOutgoing() {
        byte[] buffer = new byte[cos.getTotalBytesWritten()];
        buffer = baos.toByteArray();
        try {
            baos.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return buffer;
    }
}
