package org.devgroup.services.lms.message;

import java.io.IOException;

import org.devgroup.services.core.field.builder.LongFieldFactory;
import org.devgroup.services.core.field.builder.StringFieldFactory;
import org.devgroup.services.core.field.model.LongFieldArrayDTO.LongFieldArray;
import org.devgroup.services.lms.message.model.RoundTripLatencyMessageDTO.RoundTripLatencyMessage;
import org.devgroup.services.lms.message.model.RoundTripLatencyMessageDTO.RoundTripLatencyMessage.Builder;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.google.protobuf.CodedOutputStream;

public class RoundTripMessageEncoder {
    
    private static Logger logger = LoggerFactory.getLogger(RoundTripMessageEncoder.class);
    
    public static RoundTripLatencyMessage.Builder typeBuilder;
    RoundTripLatencyMessage outgoing;
    LongFieldArray.Builder longFieldArrayBuilder;
    
    public RoundTripMessageEncoder() {
        this.typeBuilder = RoundTripLatencyMessage.newBuilder();
        this.longFieldArrayBuilder = LongFieldArray.newBuilder();
    }
    
    public void encode(CodedOutputStream cos, long timestampCreated){
        setMessageID();
        setMessageName();
        setCreatedTimeStamp(timestampCreated);
        setSourceSentTimestamp(System.nanoTime());
        typeBuilder.setLongFields(longFieldArrayBuilder);
        try {
            typeBuilder.buildPartial().writeTo(cos);
            cos.flush();
        } catch (IOException e) {
            e.printStackTrace();
        }
        typeBuilder.clear();
        longFieldArrayBuilder.clear();
    }
    
    private void setMessageID(){
        long id = 901L;
        typeBuilder.setMessageIdentifier(LongFieldFactory.addLongFieldAndSetContent(id));
    }
    
    private void setMessageName(){
        typeBuilder.setMessageName(StringFieldFactory.addLongFieldAndSetContent(this.getClass().getCanonicalName()));
    }
    
    private void setCreatedTimeStamp(long value){
        longFieldArrayBuilder.addLongField(LongFieldFactory.addLongFieldAndSetContent(value));
    }
    
    private void setSourceSentTimestamp(long value){
        longFieldArrayBuilder.addLongField(LongFieldFactory.addLongFieldAndSetContent(value));
    }
    
    private void setReceiverCapturedTimestamp(long value){
        longFieldArrayBuilder.addLongField(LongFieldFactory.addLongFieldAndSetContent(value));
    }
    
    private void setReceiverSentTimestamp(long value){
        longFieldArrayBuilder.addLongField(LongFieldFactory.addLongFieldAndSetContent(value));
    }
    
    private void setSourceCapturedTimestamp(long value){
        longFieldArrayBuilder.addLongField(LongFieldFactory.addLongFieldAndSetContent(value));
    }
}
