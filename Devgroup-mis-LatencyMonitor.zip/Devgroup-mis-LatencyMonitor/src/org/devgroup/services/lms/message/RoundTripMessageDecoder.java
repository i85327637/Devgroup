package org.devgroup.services.lms.message;

import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import org.devgroup.services.IMessageDecoder;
import org.devgroup.services.ISubcriber;
import org.devgroup.services.core.field.model.LongFieldArrayDTO.LongFieldArray;
import org.devgroup.services.core.field.model.LongFieldDTO.LongField;
import org.devgroup.services.lms.message.model.RoundTripLatencyMessageDTO.RoundTripLatencyMessage;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.google.protobuf.InvalidProtocolBufferException;
import com.google.protobuf.Descriptors.FieldDescriptor;

public class RoundTripMessageDecoder implements IMessageDecoder {
    
    private static Logger logger = LoggerFactory.getLogger(RoundTripMessageDecoder.class);
    
    public static RoundTripLatencyMessage.Builder typeBuilder;
    public static RoundTripLatencyMessage incoming;
    
    static {
        typeBuilder = RoundTripLatencyMessage.newBuilder();
        incoming = RoundTripLatencyMessage.getDefaultInstance();
    }

    // Do nothing, let ClassLoader load...
    public static void bootstrap(){ }
    
    @Override
    public long[] decode(byte[] payload, long sTimestampReceived) {
        long[] timestampContainer = new long[5];
        try {
            incoming = typeBuilder.mergeFrom(payload).buildPartial();
            int i = 0;
            for(LongField field : incoming.getLongFields().getLongFieldList()){
                timestampContainer[i] = field.getFieldContent();
                i++;
            }
            timestampContainer[4] = sTimestampReceived;
//            for( Entry<FieldDescriptor, Object> entry : incoming.getAllFields().entrySet()){
//                logger.info("key=" + entry.getKey() + ",value=" + entry.getValue());
//            }
            typeBuilder.clear();
            typeBuilder.clearLongFields();
        } catch (InvalidProtocolBufferException e) {
            e.printStackTrace();
        }
        return timestampContainer;
    }

}
