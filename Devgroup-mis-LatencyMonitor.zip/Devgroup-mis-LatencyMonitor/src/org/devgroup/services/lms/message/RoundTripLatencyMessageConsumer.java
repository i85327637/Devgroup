package org.devgroup.services.lms.message;

import java.io.ByteArrayInputStream;
import java.io.IOException;

import org.devgroup.infrastructre.repository.task.RoundTripLatency;
import org.devgroup.services.IMessageConsumer;
import org.devgroup.services.IMessageDecoder;
import org.devgroup.services.ISubcriber;
import org.devgroup.services.lms.message.RoundTripMessageDecoder;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import com.google.protobuf.CodedInputStream;

public class RoundTripLatencyMessageConsumer implements IMessageConsumer {
    
    private static Logger logger = LoggerFactory.getLogger(RoundTripLatencyMessageConsumer.class);
    
    private static int givenMessageID = 901;
    private ByteArrayInputStream bais = null;
    private CodedInputStream cis = null;
    private byte[] payload = null;
    private RoundTripLatency data = null;
    private int incomingMessageID = 0;
    private long incomingTimeStampCreated = 0L;
    private long sTimestampReceived = 0L;
    private int incomingMessageSize = 0;
    private RoundTripMessageDecoder decoder;
    private ISubcriber subcriber = null;
    
    public RoundTripLatencyMessageConsumer(ISubcriber subcriber) {
        this.decoder = new RoundTripMessageDecoder();
        this.subcriber = subcriber;
    }
    
    @Override
    public void onMessageArrival(byte[] binaryMessage, long sTimestampReceived) throws Exception {
        this.cis = CodedInputStream.newInstance(binaryMessage);
        this.incomingMessageSize = binaryMessage.length;
        this.sTimestampReceived = sTimestampReceived;
        readMessage();
    }

    private void readMessage() throws Exception {
        readHeader();
        readPayload();
    }
    
    private void readHeader() throws Exception {
        validate();
    }
    
    private void readPayload() throws Exception {
        try {
            this.payload = cis.readRawBytes(incomingMessageSize - cis.getTotalBytesRead());
            this.subcriber.listen(decoder.decode(payload, sTimestampReceived));
        } catch (IOException e) {
            // Error from Protobuf
            e.printStackTrace();
        }
    }

    private void validate() throws Exception {
        try {
            this.incomingMessageID = cis.readRawVarint32();
            logger.debug("incomingMessageID=" + incomingMessageID);
            if(incomingMessageID != givenMessageID){
                throw new Exception("Shouldnt be capturing this message, " + incomingMessageID + "," + givenMessageID);
            } else {
                this.incomingTimeStampCreated = cis.readRawVarint64();
            }
        } catch (IOException e) {
            // Let ONLY catch the protobuf error, others let go up and throw.
            e.printStackTrace();
        }
        
    }

    

}
