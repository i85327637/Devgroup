package org.devgroup.services;

public interface IMessageConsumer {
    
    public void onMessageArrival(byte[] binaryMessage, long sTimestampReceived) throws Exception;
    
}
