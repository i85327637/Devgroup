package org.devgroup.services;

public interface IMessageCreator {

}
