package org.devgroup.services.core.message.builder;

public class IEntity {

}
