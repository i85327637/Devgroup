package org.devgroup.services.core.message.builder;

public interface IPayloadBuilder {
    public void constructPayload(IEntity record);
}
