package org.devgroup.services.core.field.builder;

import org.devgroup.services.core.field.model.LongFieldDTO.LongField;

public class LongFieldFactory {
    
    public static LongField.Builder addLongFieldAndSetContent(long value){
        return LongField.newBuilder().setFieldContent(value);
    }
    
}
