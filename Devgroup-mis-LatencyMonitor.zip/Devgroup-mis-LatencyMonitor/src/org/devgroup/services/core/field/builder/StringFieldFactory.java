package org.devgroup.services.core.field.builder;

import org.devgroup.services.core.field.model.StringFieldDTO.StringField;

public class StringFieldFactory {
    
    public static StringField.Builder addLongFieldAndSetContent(String value){
        return StringField.newBuilder().setFieldContent(value);
    }
    
}
