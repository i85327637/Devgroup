package org.devgroup.services.core.field.builder;

import org.devgroup.services.core.field.model.LongFieldArrayDTO.LongFieldArray;
import org.devgroup.services.core.field.model.LongFieldArrayDTO.LongFieldArray.Builder;

public class LongFieldArrayFactory {
    
    public static Builder addLongField(long value){
        return LongFieldArray.newBuilder().addLongField(LongFieldFactory.addLongFieldAndSetContent(value));
    }
    
}
