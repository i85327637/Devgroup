package org.devgroup.services.dbis.view;

import java.util.Map;
import java.util.Map.Entry;

import org.h2.server.web.WebServlet;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.context.embedded.ServletRegistrationBean;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class H2GUIProvider {
    
    private static Logger logger = LoggerFactory.getLogger(H2GUIProvider.class);
    
    // This Bean provides developers the accessibility to H2 Console from http://localhost:8080/h2-console
    @Bean
    public ServletRegistrationBean h2ServletRegistration(){
        ServletRegistrationBean registration = new ServletRegistrationBean(new WebServlet());
        registration.addUrlMappings("/h2-console/*");
        logger.info(registration.getServletName());
        Map<String, String> map = registration.getInitParameters();
        StringBuilder sb = new StringBuilder();
        sb.append("==== H2ServeletRegistration ====\n");
        for(Entry e : map.entrySet()){
            sb.append("key=" + e.getKey() + ",value=" + e.getValue() + "\n");
        }
        sb.append("==== H2ServeletRegistration ====\n");
        logger.info(sb.toString());
        return registration;
    }
    
}
