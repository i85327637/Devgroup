package org.devgroup.tools;

import java.io.File;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;

/*
 * Using H2 by File.
 * If there is no DBFile under deployment, meaning that this is intial load of DBSchema.
 * So search the file, if there is exising file, read and use.
 * if not, then file is created with Jooq CodeGeneration.
 * Reading sql can be read from .sql (<= not yet done...)
 */

public class DBTableBuilder {
    
    private static String filePath = "./deployment/";
    private static String dataBase = "TimeSeriesRecording";
    private static String dbSuffix = ".h2.db";
    private static String fileName =  filePath + dataBase + dbSuffix;
    
    public static void createTable(){
        
        if(!doesReadableDatabaseFileExists(new File(fileName))){
            System.out.println("Creating database for " + fileName);
            try {
                Class.forName("org.h2.Driver");
                Connection connection = DriverManager.getConnection("jdbc:h2:file:./deployment/TimeSeriesRecording", "root", "root");
                Statement statement = connection.createStatement();
                statement.executeUpdate("CREATE TABLE ROUNDTRIPLATENCY (CREATEDAT BIGINT NOT NULL PRIMARY KEY, STIMESENT BIGINT NOT NULL, RTIMERECEIVED BIGINT NOT NULL, RTIMESENT BIGINT NOT NULL, STIMERECEIVED BIGINT NOT NULL)");
//                runJooqCodeGeneration();
                statement.close();
                connection.close();
            } catch (Exception e){
                e.printStackTrace();
            }
        } else {
            System.out.println("Database ready for " + fileName);
        }
    }
    
    private static boolean doesReadableDatabaseFileExists(File file){
        return ((file.exists() && file.isFile()) ? true : false);
    }
    
    private static void runJooqCodeGeneration() throws ClassNotFoundException, NoSuchMethodException, SecurityException, IllegalAccessException, IllegalArgumentException, InvocationTargetException{
        Class<?> clazz = Class.forName("org.jooq.util.GenerationTool");
        System.out.println(clazz.getCanonicalName());
        Method method = clazz.getMethod("main", String[].class);
        
        final Object[] args = new Object[1];
        args[0] = new String[] { "resources/config/codegen.xml" };
//      args[0] = new String[] { "param1", "param2", "param3" };
        method.invoke(null, args);
    }
    
//    public static void main(String[] args){
//        createTable();
//    }
    
}
