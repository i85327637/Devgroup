package org.devgroup;

import static ch.qos.logback.core.status.StatusUtil.filterStatusListByTimeThreshold;

import java.text.MessageFormat;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import org.apache.commons.lang3.StringUtils;
import org.devgroup.tools.DBTableBuilder;
import org.h2.server.web.WebServlet;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.context.embedded.ServletRegistrationBean;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ImportResource;

import ch.qos.logback.classic.LoggerContext;
import ch.qos.logback.classic.joran.JoranConfigurator;
import ch.qos.logback.core.joran.spi.JoranException;
import ch.qos.logback.core.status.Status;
import ch.qos.logback.core.status.StatusManager;
import ch.qos.logback.core.util.StatusPrinter;

/**
 * Class which runs the Spring Boot Application using main method.
 * 
 * @author S.Kato
 * @see #run(Object, String[])
 * @see #run(Object[], String[])
 * @see #SpringApplication(Object...)
 */
@SpringBootApplication
@ImportResource("file:resources/config/phase/spring_server.xml")
public class ComponentInvoker {
    
    private static Logger logger = LoggerFactory.getLogger(ComponentInvoker.class);
    
    // This Bean provides developers the accessibility to H2 Console from http://localhost:8080/h2-console
//    @Bean
//    public ServletRegistrationBean h2ServletRegistration(){
//        ServletRegistrationBean registration = new ServletRegistrationBean(new WebServlet());
//        registration.addUrlMappings("/h2-console/*");
//        logger.info(registration.getServletName());
//        Map<String, String> map = registration.getInitParameters();
//        StringBuilder sb = new StringBuilder();
//        sb.append("==== H2ServeletRegistration ====\n");
//        for(Entry e : map.entrySet()){
//            sb.append("key=" + e.getKey() + ",value=" + e.getValue() + "\n");
//        }
//        sb.append("==== H2ServeletRegistration ====\n");
//        logger.info(sb.toString());
//        return registration;
//    }
        
    public static void main(String[] args){
        logger.info("*** Starting Spring Application ***");
        loggerInitializer();
        String springprofilesActive = System.getProperty("spring.profiles.active");
        // Allows only if -Dspring.profiles.active=product or -Dspring.profiles.active=develop 
        if (!StringUtils.equals(springprofilesActive, "product")
                && !StringUtils.equals(springprofilesActive, "develop")){
            throw new UnsupportedOperationException(
                MessageFormat.format(
                    "Missing JVM options on startup : [-Dspring.profiles.active=" + springprofilesActive + "]", springprofilesActive)
                );
        }
        logger.info("SpringApplication Starting by SprinApplication.run()");
        
        ApplicationContext ctx = SpringApplication.run(ComponentInvoker.class, args);
        
        java.util.Properties properties = System.getProperties();
        logger.info("=== Printing System Properties ===");
        for (String propertyName : properties.stringPropertyNames()) {
            String propertyValue = properties.getProperty(propertyName);
            logger.info("    {"+ propertyName + "=" + propertyValue + "}");
        }
        logger.info("=== Printed System Properties ===");
        logger.info("SpringApplication Started : Servlet Container loaded");
        
        String[] beanNames = ctx.getBeanDefinitionNames();
        Arrays.sort(beanNames);
        for (String beanName : beanNames) {
            logger.info("[Bean=" + beanName + "]");
        }
        logger.info("Spring Beans are all loaded");
        DBTableBuilder.createTable();
        logger.info("H2 READY");
    }
    
    private static void loggerInitializer() {
        LoggerContext loggerContext = (LoggerContext) LoggerFactory.getILoggerFactory();
        JoranConfigurator configurator = new JoranConfigurator();
        configurator.setContext(loggerContext);
        loggerContext.reset();
        try {
        configurator.doConfigure("./resources/config/phase/logback.xml");
        } catch (JoranException ex) {
            ex.printStackTrace();
        }
        StatusPrinter.printInCaseOfErrorsOrWarnings(loggerContext);
        logger.info("=== Printing LoggerContext ===");
        StatusPrinter.print(loggerContext);
        logger.info("=== Printed LoggerContext ===");
    }
}
