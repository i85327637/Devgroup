package org.devgroup.infrastructre.repository.task;

import org.devgroup.infrastructre.repository.task.CRUDTaskExecutor.PersistTask;

public interface IPersistenceRequestExecutor {
    public void onPersistenceRequestSubmittion(PersistTask task);
}
