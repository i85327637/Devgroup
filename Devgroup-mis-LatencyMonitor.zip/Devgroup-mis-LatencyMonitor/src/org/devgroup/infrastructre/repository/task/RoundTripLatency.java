package org.devgroup.infrastructre.repository.task;


public class RoundTripLatency {
    
    private Long timeStampCreated;
    private Long timeStampSourceSent;
    private Long timeStampReceiverCaptured;
    private Long timeStampReceiverSent;
    private Long timeStampSourceCaputured;
    
    public RoundTripLatency(Long timeStampCreated, Long timeStampSourceSent, Long timeStampReceiverCaptured,
            Long timeStampReceiverSent, Long timeStampSourceCaputured) {
        super();
        this.timeStampCreated = timeStampCreated;
        this.timeStampSourceSent = timeStampSourceSent;
        this.timeStampReceiverCaptured = timeStampReceiverCaptured;
        this.timeStampReceiverSent = timeStampReceiverSent;
        this.timeStampSourceCaputured = timeStampSourceCaputured;
    }
    
    public Long getTimeStampCreated() {
        return timeStampCreated;
    }

    public void setTimeStampCreated(Long timeStampCreated) {
        this.timeStampCreated = timeStampCreated;
    }

    public Long getTimeStampSourceSent() {
        return timeStampSourceSent;
    }

    public void setTimeStampSourceSent(Long timeStampSourceSent) {
        this.timeStampSourceSent = timeStampSourceSent;
    }

    public Long getTimeStampReceiverCaptured() {
        return timeStampReceiverCaptured;
    }

    public void setTimeStampReceiverCaptured(Long timeStampReceiverCaptured) {
        this.timeStampReceiverCaptured = timeStampReceiverCaptured;
    }

    public Long getTimeStampReceiverSent() {
        return timeStampReceiverSent;
    }

    public void setTimeStampReceiverSent(Long timeStampReceiverSent) {
        this.timeStampReceiverSent = timeStampReceiverSent;
    }

    public Long getTimeStampSourceCaputured() {
        return timeStampSourceCaputured;
    }

    public void setTimeStampSourceCaputured(Long timeStampSourceCaputured) {
        this.timeStampSourceCaputured = timeStampSourceCaputured;
    }
    
}
