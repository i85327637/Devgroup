package org.devgroup.infrastructre.repository.task;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Executor;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

import org.devgroup.component.IComponent;
import org.devgroup.component.LMSEngine;
import org.jooq.DSLContext;
import org.jooq.SQLDialect;
import org.jooq.h2.generated.tables.Roundtriplatency;
import org.jooq.h2.generated.tables.records.RoundtriplatencyRecord;
import org.jooq.impl.DSL;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class CRUDTaskExecutor implements IPersistenceRequestExecutor {
    
    private static Logger logger = LoggerFactory.getLogger(CRUDTaskExecutor.class);
    
    private ExecutorService executorService;
    private Connection connection;
    private Statement statement;
    private DSLContext dslContext;
    
    public CRUDTaskExecutor() {
        try {
            this.executorService = Executors.newSingleThreadExecutor();
            this.connection = DriverManager.getConnection("jdbc:h2:file:./deployment/TimeSeriesRecording", "root", "root");
            this.statement = connection.createStatement();
            this.dslContext = DSL.using(connection, SQLDialect.H2);
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    
    @Override
    public void onPersistenceRequestSubmittion(final PersistTask persistTask){
        Future<Boolean> result = executorService.submit(persistTask);
        Boolean code = null;
        try {
            code = result.get();
        } catch (InterruptedException e) {
            e.printStackTrace();
        } catch (ExecutionException e) {
            e.printStackTrace();
        } finally {
            if(!code){
                logger.error("Persistence Failed");
            } else {
                logger.info("Persisted");
            }
        }
    }
    
    public abstract class PersistTask implements Callable<Boolean>{
        
        private RoundTripLatency data;
        
        public PersistTask(RoundTripLatency data) {
            this.data = data;
        }
        
        @Override
        public Boolean call() {
            RoundtriplatencyRecord record = dslContext.newRecord(Roundtriplatency.ROUNDTRIPLATENCY);
            try {
                record.setCreatedat(data.getTimeStampCreated());
                record.setStimesent(data.getTimeStampSourceSent());
                record.setRtimereceived(data.getTimeStampReceiverCaptured());
                record.setRtimesent(data.getTimeStampReceiverSent());
                record.setStimereceived(data.getTimeStampSourceCaputured());
                record.store();
                return true;
            } catch (Exception e){
                e.printStackTrace();
            }
            // shouldn't reach here...
            return false;
        }
    }
    
}
