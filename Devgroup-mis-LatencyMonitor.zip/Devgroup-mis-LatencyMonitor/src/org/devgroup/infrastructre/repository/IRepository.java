package org.devgroup.infrastructre.repository;

import org.springframework.data.repository.Repository;

public interface IRepository<T> {
    
//    void store(RoundTripLatencyRecord record);
//    void readRoundTripLatencyRecord(RoundTripLatencyRecord record);
//    void deleteRoundTripLatencyRecord(RoundTripLatencyRecord record);
//    void updateRoundTripLatencyRecord(RoundTripLatencyRecord record);
}
