package org.devgroup.infrastructre.transport.socket.io.udp.unicast;

import java.net.InetAddress;
import java.net.UnknownHostException;

import org.devgroup.infrastructre.transport.ITransport;
import org.devgroup.services.IMessageConsumer;

public class SocketIOTransport implements ITransport {
    
    public UDPDatagramUnicastSender newSource() throws UnknownHostException{
        return new UDPDatagramUnicastSender(InetAddress.getLocalHost(), 63999);
    }
    
    // Set the size of MTU for single message
    // If Application receiving large message, then
    // Packets are dispatched with IP Fragmented Size,
    // So set the largest size * 3;
    // To be precise, this buffer is for Potential messageSize
    // for this Socket to be receiving until captured Multiple Datagram size
    // Combined, and needs to consider the simutaneous receiving of other datagram
    // from the others...
    public UDPDatagramUnicastReceiver newReceiver(IMessageConsumer consumer){
        int port = 63999;
        int byteBufferSize = 8192;
        return new UDPDatagramUnicastReceiver(port, byteBufferSize, consumer);
    }
    
}
