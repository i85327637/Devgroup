package org.devgroup.infrastructre.transport.socket.io.udp.unicast;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.SocketException;
import java.net.SocketTimeoutException;
import java.util.Arrays;

import org.devgroup.infrastructre.transport.socket.IDatagramReceiver;
import org.devgroup.services.IMessageConsumer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class UDPDatagramUnicastReceiver implements IDatagramReceiver{
    
    private static Logger logger = LoggerFactory.getLogger(UDPDatagramUnicastReceiver.class);
    
    private InetAddress sAddr;
    private int sPort;
    private InetAddress rAddr;
    private int rPort;
    private DatagramSocket rSocket;
    private int msReceiveBufferSize;
    private byte[] mrReceiveBuffer;
    private volatile boolean isShutdown = false;
    
    public UDPDatagramUnicastReceiver(int rPort, int msReceiveBufferSize, IMessageConsumer consumer) {
        try {
            this.msReceiveBufferSize = msReceiveBufferSize;
            this.mrReceiveBuffer = new byte[this.msReceiveBufferSize];
            this.rPort = rPort;
            this.rSocket = new DatagramSocket(this.rPort);
            // 10sec for timeout when shutdown
            this.rSocket.setSoTimeout(10000);
        } catch (SocketException e) {
            e.printStackTrace();
        }
        new Thread(new Runnable() {
            
            @Override
            public void run() {
                try {
                    while(true) {
                        if(isShutdown) {
                            return;
                        }
                        try {
                            DatagramPacket captured = new DatagramPacket(mrReceiveBuffer, mrReceiveBuffer.length);
                            rSocket.receive(captured);
                            long sTimestampReceived = System.nanoTime();
                            int dataSize = captured.getLength();
                            logger.debug("capturedSize=" + dataSize);
                            byte received[] = new byte[dataSize];
                            received = Arrays.copyOf(captured.getData(), dataSize);
                            onDatagramCaptured(received, consumer, sTimestampReceived);
                        } catch (SocketTimeoutException e){
                            logger.error(e.getMessage());
                        }
                    }
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }, "SocketReceiverThread").start();
    }

    @Override
    public void onDatagramCaptured(byte[] received, IMessageConsumer consumer, long sTimestampReceived) {
        try {
            consumer.onMessageArrival(received, sTimestampReceived);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    
    public void shutDown(){
        this.isShutdown = true;
    }
    
}
