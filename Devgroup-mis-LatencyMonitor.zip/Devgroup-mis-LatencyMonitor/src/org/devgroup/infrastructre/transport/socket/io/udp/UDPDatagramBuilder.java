package org.devgroup.infrastructre.transport.socket.io.udp;

import java.net.DatagramPacket;
import java.net.InetAddress;
import java.net.SocketAddress;

public class UDPDatagramBuilder {

    public static DatagramPacket build(byte[] msgData, int msgSize, InetAddress dAddr, int dPort){
        return new DatagramPacket(msgData, msgSize, dAddr, dPort);
    }
    
}
