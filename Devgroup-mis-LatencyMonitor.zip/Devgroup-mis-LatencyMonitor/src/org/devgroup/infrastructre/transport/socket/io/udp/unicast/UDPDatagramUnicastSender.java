package org.devgroup.infrastructre.transport.socket.io.udp.unicast;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.SocketException;

import org.devgroup.infrastructre.transport.IMessageSource;
import org.devgroup.infrastructre.transport.socket.io.udp.UDPDatagramBuilder;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class UDPDatagramUnicastSender implements IMessageSource {
    
    private static Logger logger = LoggerFactory.getLogger(UDPDatagramUnicastSender.class);
    
    private InetAddress sAddr;
    private int sPort;
    private InetAddress dAddr;
    private int dPort;
    private DatagramSocket sSocket;
    private int sSendBuf;
    private boolean canReuse;
    
    // Send Buffer allocated for IMessageSource
    private byte msSendBuffer[];

    private byte[] msSendRetentionBuffer;
    
    public UDPDatagramUnicastSender(InetAddress dAddr, int dPort) {
        this.dAddr = dAddr;
        this.dPort = dPort;
        try {
            this.sSocket = new DatagramSocket();
            this.sAddr = sSocket.getLocalAddress();
            this.sPort = sSocket.getLocalPort();
            this.sSendBuf = sSocket.getSendBufferSize();
            this.canReuse = sSocket.getReuseAddress();
        } catch (SocketException e) {
            e.printStackTrace();
        }
        this.msSendBuffer = new byte[8192];
        // 65508 for UDP Max... but then... use MTU size instead... 
//        this.msSendRetentionBuffer = new byte[65508];
        logger.info("SenderSocketInfo [sAddr=" + sAddr + ",sPort=" + sPort + ",sSendBuf=" + sSendBuf + " bytes,canReuse=" + canReuse + "]");
    }
    
    @Override
    public void doSend(byte[] msgData, int msgSize) {
        try {
            msSendBuffer = msgData;
            sSocket.send(UDPDatagramBuilder.build(msgData, msgSize, dAddr, dPort));
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            msSendRetentionBuffer = new byte[msgSize];
            msSendRetentionBuffer = msgData;
        }
    }
    
    @Override
    public void doRetransmit() {
        
    }
    
}
