package org.devgroup.infrastructre.transport.socket;

import java.net.DatagramSocket;
import java.net.SocketException;

public class UDPSocket {

    private int port;
    private DatagramSocket datagramSocket;
    
    public UDPSocket(int port) {
        this.port = port;
        try {
            this.datagramSocket = new DatagramSocket(this.port);
        } catch (SocketException e) {
            e.printStackTrace();
        }
        System.out.println("INFO : [instance=UDPSocket, port=" + this.port + "]");
    }
    
    public DatagramSocket getDatagramSocket() {
        return datagramSocket;
    }

    public void setDatagramSocket(DatagramSocket datagramSocket) {
        this.datagramSocket = datagramSocket;
    }

    public static UDPSocket createUDPSocket(int port){
        return new UDPSocket(port);
    }
}
