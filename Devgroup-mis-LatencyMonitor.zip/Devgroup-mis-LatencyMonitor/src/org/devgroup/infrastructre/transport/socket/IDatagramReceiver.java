package org.devgroup.infrastructre.transport.socket;

import org.devgroup.services.IMessageConsumer;

public interface IDatagramReceiver {
    
    void onDatagramCaptured(byte[] received, IMessageConsumer consumer, long rTimestampReceived);
}
