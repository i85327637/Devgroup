package org.devgroup.infrastructre.transport.socket;

public interface IByteStreamReceiver {

}
