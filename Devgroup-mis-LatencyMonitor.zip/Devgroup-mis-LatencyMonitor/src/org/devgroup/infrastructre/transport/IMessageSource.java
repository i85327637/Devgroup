package org.devgroup.infrastructre.transport;

public interface IMessageSource {
    void doSend(byte[] msgData, int msgSize);
    void doRetransmit();
    
}
