package org.devgroup.infrastructre.transport;

public interface ITransport {

}
